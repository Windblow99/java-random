
package utility;

public class Text {

    public static String append(String s1, String s2) {
//      System.out.println( s2.concat(s1) );
        return s2.concat(s1);
    }

    public static String prepend(String s1, String s2) {
//      System.out.println( s1.concat(s2) );
        return s1.concat(s2);
    }
}
