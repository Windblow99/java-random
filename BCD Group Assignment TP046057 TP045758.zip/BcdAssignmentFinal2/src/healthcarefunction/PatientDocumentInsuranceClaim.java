package healthcarefunction;

import block.Block;
import block.Blockchain;
import entity.Patient;
import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import key.AsymmetricCrypto;
import utility.FileIO;
import utility.Session;



public class PatientDocumentInsuranceClaim {
    private static Map<String, List<String>> documentNameValue;
    
    //getter and setter
    public Map<String, List<String>> getDocumentNameValue() {
        return documentNameValue;
    }

    public void setDocumentNameValue(Map<String, List<String>> documentNameValue) {
        this.documentNameValue = documentNameValue;
    }
            
    
    //constructor
    public PatientDocumentInsuranceClaim() {
        try {
            documentNameValue = new HashMap<>();

        } catch (Exception e) {
            e.printStackTrace();
        }
    }
    
    //read from the chain, filter receiver
    public void getReceiverLst(JList jlist){
        List<String> receiverLst = FileIO.read("login.txt");
        DefaultListModel listModel = new DefaultListModel();
        
        if (receiverLst.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No appropriate receiver is found.");
            return;
        }
        
        for(String receiver : receiverLst){
            String[] data = receiver.split("\\|");
            
            switch(Session.getRole()){
                case "healthcare personnel":
                    if (data[2].equals("patient")) {
                        listModel.addElement(data[3]);
                    }
                    break;
                    
                case "patient":
                    if (data[2].equals("insurance company")) {
                        listModel.addElement(data[3]);
                    }
                    break;
            }
        }
        jlist.setModel(listModel);
    }
    
    //helper
    public static void getReceiverUUID(String name, JTextField uuid){
        List<String> receiverLst = FileIO.read("login.txt");
        
        for(String receiver : receiverLst){
            String[] data = receiver.split("\\|");
            if (data[3].equals(name)) {
                uuid.setText(data[1]);
            }
        }
    }
    
    //read
    public static void getDocument(JList jlist){
        Blockchain bcdTool = new Blockchain();
        Map<String, List<String>> map = new HashMap<>();
        DefaultListModel listModel = new DefaultListModel();      
        List<Block> blocks = bcdTool.get();
        File file = new File("masterchain.dat");
         
        if (file.length() == 0) {
            JOptionPane.showMessageDialog(null, "No appropriate document is found.");
            
        }else{
        
            int count = 1;
            for(Block block : blocks){
                String blockString = block.toString();
                String[] data = blockString.split(",");
                String patientData = data[2];
                String[] specificPatientData = patientData.split("\\|");

                if (specificPatientData[7].equals(Session.getUuid())) {
                    //add data to the list.
                    String documentCount = "document " + count;
                    listModel.addElement(documentCount);

                    //store to retrieve document content.
                    List<String> dataLst = new ArrayList<>();
                    dataLst.add(specificPatientData[4]);
                    dataLst.add(specificPatientData[5]);
                    map.put(documentCount,dataLst);
                    count++;
                }

            }
            documentNameValue = map;
            jlist.setModel(listModel);
        }
    }
    
    //read
    public static void getDocumentContent(String document, JTextArea jtextarea){
        if (document == null) {
            JOptionPane.showMessageDialog(null, "No document is found!");
            return;
        }
        
        List<String> docuData = documentNameValue.get(document);
        jtextarea.setText(docuData.get(0));
    }
    
    //helper
    public static void getDocumentDigitalSignature(String document, JTextField jtextfield){
        if (document == null) {
            return;
        }
        
        List<String> docuData = documentNameValue.get(document);
        jtextfield.setText(docuData.get(1));
    }
    
    //Communication
    public void sendFromHospitalToPatient(String data, String receiverUUID, String path) throws Exception{
        if (data.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please enter something.");
            return;
        }
        if (receiverUUID.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please select a receiver.");
            return;
        }
        if(path.isEmpty()){
            JOptionPane.showMessageDialog(null, "Please attach your private key.");
            return;
        }
        
        //prepare data for persist
        AsymmetricCrypto tool = new AsymmetricCrypto();
        String ds = tool.sign(data,path);
        
        //FORMAT: md1 | md2 | md3 | md4 | document content | digital signature | creator UUID | receiver UUID
        Patient patient = new Patient("null", "null", "null", "null", data, ds, Session.getUuid(), receiverUUID);
        String patientRec = patient.toString();
        
        //persist to blockchain..
        LinkedList<Block> db = new LinkedList<>();
        Blockchain bcdTool = new Blockchain();
        LinkedList<Block> chain = bcdTool.get();
                    
        //first block
        if(chain == null) {
            Block genesisBlock = new Block("0", patientRec); //0 is the previous hash
            bcdTool.nextBlock(genesisBlock);
            
        //second block and onwards 
        }else{
            db = chain;
            bcdTool.setDb(db);
            Block block = new Block(chain.getLast().getHash(), patientRec);
            bcdTool.nextBlock(block);
        }
        bcdTool.persist();
        bcdTool.distribute();
           
        JOptionPane.showMessageDialog(null, "Sent successfully.");
    }
    
    //Communication
    public void sendFromPatientToInsuranceCompany(String data, String digitalSignature, String receiverUUID) throws Exception{
        if (data.isEmpty() || digitalSignature.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please select a document.");
            return ;
        }
        
        if(receiverUUID.isEmpty()){
            JOptionPane.showMessageDialog(null, "Please select a receiver.");
            return;
        }
        
        //FORMAT: md1 | md2 | md3 | md4 | document content | digital signature | creator UUID | receiver UUID
        Patient patient = new Patient("null", "null", "null", "null", data, digitalSignature, Session.getUuid(), receiverUUID);
        String patientRec = patient.toString();
        
        //persist to blockchain..
        LinkedList<Block> db = new LinkedList<>();
        Blockchain bcdTool = new Blockchain();
        LinkedList<Block> chain = bcdTool.get();
                    
        //second block onwards
        db = chain;
        bcdTool.setDb(db);
        Block block = new Block(chain.getLast().getHash(), patientRec);
        bcdTool.nextBlock(block);
        bcdTool.persist();
        bcdTool.distribute();
        
        JOptionPane.showMessageDialog(null, "Sent successfully.");
    }
    
    //Communication
    public boolean verifyByInsuranceCompany(String data, String ds, String path)throws Exception{ 
        if (data.isEmpty() || ds.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please select a document.");
            return false;
        }
        if(path.isEmpty()){
            JOptionPane.showMessageDialog(null, "Please attach the public key of the hospital personnel.");
            return false;
        }
        JOptionPane.showMessageDialog(null, "Finished verifying the document.");
        AsymmetricCrypto tool = new AsymmetricCrypto();
        boolean isValid = tool.verify(data, ds, path);
        return isValid;
    }
}
