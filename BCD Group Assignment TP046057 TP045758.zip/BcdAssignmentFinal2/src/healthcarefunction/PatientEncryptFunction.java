package healthcarefunction;

import block.Block;
import block.Blockchain;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import javax.swing.DefaultListModel;
import javax.swing.JList;
import javax.swing.JOptionPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import utility.FileIO;
import utility.Session;

public class PatientEncryptFunction {
    private static Map<String, String> documentNameValue;
    
    //getter and setter
    public Map<String, String> getDocumentNameValue() {
        return documentNameValue;
    }

    public void setDocumentNameValue(Map<String, String> documentNameValue) {
        this.documentNameValue = documentNameValue;
    }
    
    public static void decrypt(String encrypted, String filePath, JTextArea decrypted) throws Exception {
        if (encrypted.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please select a receiver.");
            return;
        }
        
        if(filePath.isEmpty()){
            JOptionPane.showMessageDialog(null, "Please attach your public key.");
            return;
        }
        
        key.AsymmetricCrypto crypto = new key.AsymmetricCrypto();            
        decrypted.setText(crypto.decrypt(encrypted, key.KeyRetriever.getPrivateKey(filePath))); 
        JOptionPane.showMessageDialog(null, "Decrypted successfully.");
    }
    
    public static boolean encrypt(String data, String filePath, JTextField encrypted, String uuid) throws Exception {
        if (uuid.isEmpty()) {
            JOptionPane.showMessageDialog(null, "Please select a receiver.");
            return false;
        }
        
        if(filePath.isEmpty()){
            JOptionPane.showMessageDialog(null, "Please attach your public key.");
            return false;
        }
        
        key.AsymmetricCrypto crypto = new key.AsymmetricCrypto();
        String encryptedText = crypto.encrypt(data, key.KeyRetriever.getPublicKey(filePath));           
        encrypted.setText(encryptedText);    
        JOptionPane.showMessageDialog(null, "Created and sent successfully!");
        return true;
    }
    
    public void getMedicalList(JList jlist){
        List<String> receiverLst = FileIO.read("login.txt");
        DefaultListModel listModel = new DefaultListModel();
        
        if (receiverLst.isEmpty()) {
            JOptionPane.showMessageDialog(null, "No appropriate receiver is found.");
            return;
        }
        
        for(String receiver : receiverLst){
            String[] data = receiver.split("\\|");
            
            if (data[2].equals("healthcare personnel")) {
                listModel.addElement(data[3]);
            }
        }
        jlist.setModel(listModel);
    }
    
    public static void getMedicalUUID(String name, JTextField uuid){
        List<String> receiverLst = FileIO.read("login.txt");
        
        for(String receiver : receiverLst){
            String[] data = receiver.split("\\|");
            if (data[3].equals(name)) {
                uuid.setText(data[1]);
            }
        }
    }
    
    public static void getEncrypted(JList jlist){
        Blockchain bcdTool = new Blockchain();
        Map<String, String> map = new HashMap<>();
        DefaultListModel listModel = new DefaultListModel();
        List<Block> blocks = bcdTool.get();
        System.out.println(blocks);
        if (blocks == null) {
            JOptionPane.showMessageDialog(null, "No document is found!");
            return;
        }
        
        int count = 1;
        for(Block block : blocks){
            String blockString = block.toString();
            String[] trx = blockString.split(",");
            String patientData = trx[2];
            String[] specificPatientData = patientData.split("\\|");

            if (specificPatientData[7].equals(Session.getUuid())) {
                //add data to the list.
                String documentCount = "Encrypted text " + count;
                listModel.addElement(documentCount);
                
                //store to retrieve encrypted data.
                map.put(documentCount,specificPatientData[4]);
                count++;
            }          
        }
         
        documentNameValue = map;
        jlist.setModel(listModel);
    }
    
    public static void getEncryptedContent(String document, JTextField jtextarea){
        if (document == null) {
            JOptionPane.showMessageDialog(null, "No document is found!");
            return;
        }
        
        String docuData = documentNameValue.get(document);
        jtextarea.setText(docuData);
    }
}
