package entity;

import block.Block;
import java.io.ByteArrayOutputStream;
import java.io.ObjectOutputStream;


public class Patient {
    private String diagnoses;
    private String treatmentPlans;
    private String medications;
    private String immunizations;
    private String encryptedText;
    private String digitalSignature;
    private String creatorUuid;
    private String receiverUuid;

    public Patient(String diagnoses, String treatmentPlans, String medications, String immunizations, String encryptedText, String digitalSignature, String creatorUuid, String receiverUuid) {
        this.diagnoses = diagnoses;
        this.treatmentPlans = treatmentPlans;
        this.medications = medications;
        this.immunizations = immunizations;
        this.encryptedText = encryptedText;
        this.digitalSignature = digitalSignature;
        this.creatorUuid = creatorUuid;
        this.receiverUuid = receiverUuid;
    }
   
    public static byte[] getBytes(Patient patient){
        //ByteArrayOutputStream and ObjectOutputStream from io package        
        try (ByteArrayOutputStream baos = new ByteArrayOutputStream();
                ObjectOutputStream out = new ObjectOutputStream(baos)){
            out.writeObject(patient);
            return baos.toByteArray();
        } catch (Exception e) {
            return null;
        }
    }

    public String getDiagnoses() {
        return diagnoses;
    }

    public void setDiagnoses(String diagnoses) {
        this.diagnoses = diagnoses;
    }

    public String getTreatmentPlans() {
        return treatmentPlans;
    }

    public void setTreatmentPlans(String treatmentPlans) {
        this.treatmentPlans = treatmentPlans;
    }
    
    public String getMedications() {
        return medications;
    }

    public void setMedications(String medications) {
        this.medications = medications;
    }
    
    public String getImmunizations() {
        return immunizations;
    }

    public void setImmunizations(String immunizations) {
        this.immunizations = immunizations;
    }

    public String getEncryptedText() {
        return encryptedText;
    }

    public void setEncryptedText(String encryptedText) {
        this.encryptedText = encryptedText;
    }

    public String getDigitalSignature() {
        return digitalSignature;
    }

    public void setDigitalSignature(String digitalSignature) {
        this.digitalSignature = digitalSignature;
    }

    public String getCreatorUuid() {
        return creatorUuid;
    }

    public void setCreatorUuid(String creatorUuid) {
        this.creatorUuid = creatorUuid;
    }

    public String getReceiverUuid() {
        return receiverUuid;
    }

    public void setReceiverUuid(String receiverUuid) {
        this.receiverUuid = receiverUuid;
    }

    @Override
    public String toString() {
        return  diagnoses + "|" + treatmentPlans + "|" + medications + "|" + immunizations + "|" + encryptedText + "|" + digitalSignature + "|" + creatorUuid + "|" + receiverUuid;
    } 
}
