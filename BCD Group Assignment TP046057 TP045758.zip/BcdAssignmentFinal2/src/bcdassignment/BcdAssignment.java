package bcdassignment;
import healthcaregui.Welcome;


public class BcdAssignment {

    public static void main(String[] args) {
        Welcome wel = new Welcome();
        wel.setLocationRelativeTo(null);
        wel.setVisible(true);
    }
}
