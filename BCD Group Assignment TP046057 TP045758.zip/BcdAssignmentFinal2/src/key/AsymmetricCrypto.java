package key;

import static java.nio.charset.StandardCharsets.UTF_8;
import java.security.PrivateKey;
import java.security.PublicKey;
import java.security.Signature;
import java.util.Base64;
import javax.crypto.Cipher;
import javax.swing.JOptionPane;


public class AsymmetricCrypto {
    
    private Cipher cipher;
    
    public AsymmetricCrypto() throws Exception {
        this.cipher = Cipher.getInstance(KeyStoreConfig.ALGORITHM);
    }
    
    //encrypt
    public String encrypt(String data, PublicKey key) throws Exception {
        cipher.init(Cipher.ENCRYPT_MODE, key);
        byte[] cipherBytes = cipher.doFinal(data.getBytes()); //encrypted text
        return Base64.getEncoder().encodeToString(cipherBytes);
    }
    
    //decrypt
    public String decrypt(String cipherText, PrivateKey key) throws Exception {
        cipher.init(Cipher.DECRYPT_MODE, key);
        byte[] cipherBytes = Base64.getDecoder().decode(cipherText);
        byte[] originalBytes = cipher.doFinal(cipherBytes);
        return new String(originalBytes);
    }
   
    public String sign(String data, String path) throws Exception{
        
        PrivateKey pk = KeyRetriever.getPrivateKey(path);
        
        Signature priSig = Signature.getInstance("SHA256withRSA");
        priSig.initSign(pk);
        priSig.update(data.getBytes(UTF_8));
        
        byte[] signature = priSig.sign();
       
        return Base64.getEncoder().encodeToString(signature);  
    }
    
    public boolean verify(String data, String digitalSignature, String path) throws Exception{
        PublicKey pk = KeyRetriever.getPublicKey(path);
        
        Signature pubSig = Signature.getInstance("SHA256withRSA");
        pubSig.initVerify(pk);
        pubSig.update(data.getBytes(UTF_8));

        byte[] signatureBytes = Base64.getDecoder().decode(digitalSignature);

        return pubSig.verify(signatureBytes);
    }
}
