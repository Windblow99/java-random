package key;

import java.io.File;
import java.nio.file.Files;
import java.nio.file.Paths;
import java.nio.file.StandardOpenOption;
import java.security.KeyPair;
import java.security.KeyPairGenerator;
import java.security.PrivateKey;
import java.security.PublicKey;

public class KeyGen {
    private KeyPairGenerator keygen;
    private KeyPair keypair;
    private final int keysize = 1024;
    
    public KeyGen() throws Exception {
        this.keygen = KeyPairGenerator.getInstance(KeyStoreConfig.ALGORITHM);
        this.keygen.initialize(keysize);
    }
    
    //store keypair
    private static void store(String path, byte[]key) {
        File file = new File(path);
        try {
            Files.write(Paths.get(path), key, StandardOpenOption.CREATE);
        } catch (Exception e) {}
    }
    
    public static void mkKeypair() {
        try {
            //generate keypair
            KeyGen km = new KeyGen();
            km.keypair = km.keygen.generateKeyPair();
            
            //publickey
            PublicKey pukey = km.keypair.getPublic();
            
            //privatekey
            PrivateKey pvkey = km.keypair.getPrivate();
            
            //show keys
            //System.out.println(pukey.getEncoded().toString());
            
            //store keypair
            store(KeyStoreConfig.PUBLICKEY_FILE, pukey.getEncoded());
            store(KeyStoreConfig.PRIVATEKEY_FILE, pvkey.getEncoded());
        } catch (Exception e) {}
    }
}
