package key;

public class KeyStoreConfig {
    //https://stackoverflow.com/questions/30416365/general-path-to-downloads-folder
    
    static String home = System.getProperty("user.home");
    public static final String PUBLICKEY_FILE = home + "/Downloads/" + "PublicKey";
    public static final String PRIVATEKEY_FILE = home + "/Downloads/" + "PrivateKey";

    public static final String ALGORITHM = "RSA";
}
